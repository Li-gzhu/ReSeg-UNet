#!/usr/bin/env python
# -*- coding:utf-8 -*-

import argparse
import logging
import os

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from medpy.metric import dc
from torch.nn.modules.loss import CrossEntropyLoss
from torch.utils.data import DataLoader
from torchvision import transforms
from tqdm import tqdm
# import pytorch_ssim
#from Architecture.DATransUNet import CONFIGS as CONFIGS_ViT_seg
from Architecture.unet_model import UNet_hd as unet_re
from Architecture.unet_model import UNet_se as unet_se
from datasets.dataset_ACDC import ACDCdataset, RandomGenerator
# from model.MTUNet import MTUNet
# from Architecture.DATransUNet import DA_Transformer
# from utils.test_ACDC import inference
# import matplotlib.pyplot as plt
#from utils.utils import DiceLoss
import torch.nn.functional as F
#!/usr/bin/env python
# -*- coding:utf-8 -*-

import logging

import numpy as np
import torch
from tqdm import tqdm
import numpy as np
import torch
from medpy import metric
from scipy.ndimage import zoom
import torch.nn as nn
import SimpleITK as sitk

# from .utils import test_single_volume
def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    if pred.sum() > 0 and gt.sum() > 0:
        dice = metric.binary.dc(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
        return dice, hd95
    elif pred.sum() > 0 and gt.sum() == 0:
        return 1, 0
    else:
        return 0, 0


def test_single_volume(image, label, net, classes, patch_size=[256, 256], test_save_path=None, case=None, z_spacing=1):
    image, label = image.squeeze(0).cpu().detach().numpy(), label.squeeze(0).cpu().detach().numpy()
    if len(image.shape) == 3:
        prediction = np.zeros_like(label)
        for ind in range(image.shape[0]):
            slice = image[ind, :, :]
            #slice1 = image[ind, :, :]
            x, y = slice.shape[0], slice.shape[1]
            if x != patch_size[0] or y != patch_size[1]:
                slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)
                #slice1 = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)  # previous using 0
            input = torch.from_numpy(slice).unsqueeze(0).unsqueeze(0).float().cuda()
            #input_1 = torch.from_numpy(slice).unsqueeze(0).float().cuda()

            net.eval()
            with torch.no_grad():
                outputs = net(input)#, input_1
                out = torch.argmax(torch.softmax(outputs[0], dim=1), dim=1).squeeze(0)
                out = out.cpu().detach().numpy()
                if x != patch_size[0] or y != patch_size[1]:
                    pred = zoom(out, (x / patch_size[0], y / patch_size[1]), order=0)
                else:
                    pred = out
                prediction[ind] = pred
    else:
        input = torch.from_numpy(image).unsqueeze(
            0).unsqueeze(0).float().cuda()
        net.eval()
        with torch.no_grad():
            out = torch.argmax(torch.softmax(net(input), dim=1), dim=1).squeeze(0)
            prediction = out.cpu().detach().numpy()
    metric_list = []
    for i in range(1, classes):
        metric_list.append(calculate_metric_percase(prediction == i, label == i))

    if test_save_path is not None:
        img_itk = sitk.GetImageFromArray(image.astype(np.float32))
        prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
        lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
        img_itk.SetSpacing((1, 1, z_spacing))
        prd_itk.SetSpacing((1, 1, z_spacing))
        lab_itk.SetSpacing((1, 1, z_spacing))
        sitk.WriteImage(prd_itk, test_save_path + '/' + case + "_pred.nii.gz")
        sitk.WriteImage(img_itk, test_save_path + '/' + case + "_img.nii.gz")
        sitk.WriteImage(lab_itk, test_save_path + '/' + case + "_gt.nii.gz")
    return metric_list


def inference(args, model, testloader, test_save_path=None):
    logging.info("{} test iterations per epoch".format(len(testloader)))
    model.eval()
    metric_list = 0.0
    with torch.no_grad():
        for i_batch, sampled_batch in tqdm(enumerate(testloader)):
            h, w = sampled_batch["image"].size()[2:]
            image, label, case_name = sampled_batch["image"], sampled_batch["label"], sampled_batch['case_name'][0]
            metric_i = test_single_volume(image, label, model, classes=args.num_classes, patch_size=[args.img_size, args.img_size],
                                          test_save_path=test_save_path, case=case_name, z_spacing=args.z_spacing)
            metric_list += np.array(metric_i)
            logging.info('idx %d case %s mean_dice %f mean_hd95 %f' % (i_batch, case_name, np.mean(metric_i, axis=0)[0], np.mean(metric_i, axis=0)[1]))
        metric_list = metric_list / len(testloader)
        for i in range(1, args.num_classes):
            logging.info('Mean class %d mean_dice %f mean_hd95 %f' % (i, metric_list[i-1][0], metric_list[i-1][1]))
        performance = np.mean(metric_list, axis=0)[0]
        mean_hd95 = np.mean(metric_list, axis=0)[1]
        logging.info('Testing performance in best val model: mean_dice : %f mean_hd95 : %f' % (performance, mean_hd95))
        logging.info("Testing Finished!")
        return performance, mean_hd95

def inference1(args, model, testloader, test_save_path=None):
        logging.info("{} test iterations per epoch".format(len(testloader)))
        model.eval()
        metric_list = 0.0
        with torch.no_grad():
            for i_batch, sampled_batch in tqdm(enumerate(testloader)):
                h, w = sampled_batch["image"].size()[2:]
                image, label, case_name = sampled_batch["image"], sampled_batch["label"], sampled_batch['case_name'][0]
                metric_i = test_single_volume(image, label, model, classes=args.num_classes,
                                              patch_size=[args.img_size, args.img_size],
                                              test_save_path=test_save_path, case=case_name, z_spacing=args.z_spacing)
                metric_list += np.array(metric_i)
                logging.info('idx %d case %s mean_dice %f mean_hd95 %f' % (
                i_batch, case_name, np.mean(metric_i, axis=0)[0], np.mean(metric_i, axis=0)[1]))
            metric_list = metric_list / len(testloader)
            for i in range(1, args.num_classes):
                logging.info(
                    'Mean class %d mean_dice %f mean_hd95 %f' % (i, metric_list[i - 1][0], metric_list[i - 1][1]))
            performance = np.mean(metric_list, axis=0)[0]
            mean_hd95 = np.mean(metric_list, axis=0)[1]
            logging.info(
                'Testing performance in best val model: mean_dice : %f mean_hd95 : %f' % (performance, mean_hd95))
            logging.info("Testing Finished!")
            return performance, mean_hd95
class DiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(DiceLoss, self).__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor == i  # * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob.unsqueeze(1))
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _dice_loss(self, score, target):
        target = target.float()
        smooth = 1e-5
        intersect = torch.sum(score * target)
        y_sum = torch.sum(target * target)
        z_sum = torch.sum(score * score)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def forward(self, inputs, target, weight=None, softmax=False):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target)
        if weight is None:
            weight = [1] * self.n_classes

        assert inputs.size() == target.size(), 'predict {} & target {} shape do not match'.format(inputs.size(), target.size())
        class_wise_dice = []
        loss = 0.0
        for i in range(0, self.n_classes):
            dice = self._dice_loss(inputs[:, i], target[:, i])
            class_wise_dice.append(1.0 - dice.item())
            loss += dice * weight[i]
        return loss / self.n_classes
parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", default=24, help="batch size")
parser.add_argument("--lr", default=0.01, help="learning rate")
parser.add_argument("--max_epochs", default=400)
parser.add_argument("--img_size", default=224)
parser.add_argument("--save_path", default="./checkpoint/ACDC/se/sgd_all0.035_se_sgd3_trunk")
parser.add_argument("--n_gpu", default=1)
parser.add_argument("--checkpoint", default=None)
parser.add_argument("--list_dir", default="./datasets/ACDC/lists_ACDC")
parser.add_argument("--root_dir", default="./datasets/ACDC/")
parser.add_argument("--volume_path", default="./datasets/ACDC/test")
parser.add_argument("--z_spacing", default=1)
parser.add_argument("--num_classes", default=4)
parser.add_argument('--test_save_dir', default='./predictions/ACDC', help='saving prediction as nii!')
parser.add_argument("--patches_size", default=16)
# parser.add_argument("--n_skip", default=1)
parser.add_argument('--deterministic', type=int, default=1,
                    help='whether use deterministic training')
# parser.add_argument('--base_lr', type=float,  default=0.01,
#                     help='segmentation network learning rate')
# parser.add_argument('--img_size', type=int,
#                     default=224, help='input patch size of network input')
parser.add_argument('--seed', type=int,
                    default=1234, help='random seed')
parser.add_argument('--n_skip', type=int,
                    default=3, help='using number of skip-connect, default is num')
parser.add_argument('--vit_name', type=str,
                    default='R50-ViT-B_16', help='select one vit model')
parser.add_argument('--vit_patches_size', type=int,
                    default=16, help='vit_patches_size, default is 16')
args = parser.parse_args()

model = unet_se(n_channels=3, n_classes=4).cuda()

model2 = unet_re(n_channels=3, n_classes=4).cuda()
model2.load_state_dict(torch.load('./checkpoint/ACDC/epoch=149_lr=2.986698929594598e-06'))#sgd2/epoch=149_lr=2.986698929594598e-06
# model2.load_state_dict(torch.load('/home/ubuntu/桌面/DA-TransUNet-new（复件）/DA-TransUNet/checkpoint/ACDC/re/epoch=149_lr=2.986698929594598e-08'))
for param in model2.parameters():
    param.requires_grad = False
if args.checkpoint:
    model.load_state_dict(torch.load(args.checkpoint))

train_dataset = ACDCdataset(args.root_dir, args.list_dir, split="train", transform=
transforms.Compose(
    [RandomGenerator(output_size=[args.img_size, args.img_size])]))
Train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
db_val = ACDCdataset(base_dir=args.root_dir, list_dir=args.list_dir, split="valid")
valloader = DataLoader(db_val, batch_size=1, shuffle=False)
db_test = ACDCdataset(base_dir=args.volume_path, list_dir=args.list_dir, split="test")
testloader = DataLoader(db_test, batch_size=1, shuffle=False)

if args.n_gpu > 1:
    model = nn.DataParallel(model)

model = model.cuda()
model.train()
ce_loss = CrossEntropyLoss()
dice_loss = DiceLoss(args.num_classes)
save_interval = 3  # int(max_epoch/6)
# MSE = nn.MSELoss()
# L1loss = nn.L1Loss()
# yyloss = pytorch_ssim.SSIM(window_size=28, size_average=True)
iterator = tqdm(range(0, args.max_epochs), ncols=70)
iter_num = 0

Loss = []
Test_Accuracy = []

Best_dcs = 0.80
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s   %(levelname)s   %(message)s')

max_iterations = args.max_epochs * len(Train_loader)
base_lr = args.lr
#optimizer = optim.AdamW(model.parameters(), lr=base_lr, weight_decay=0.0001)


optimizer = optim.SGD(model.parameters(), lr=base_lr, momentum=0.9, weight_decay=0.0001)
# if __name__ == '__main__':
#     img_size = 224
#     x = torch.rand(1, 3, img_size, img_size).cuda()
#     model = DA_Transformer(config_vit, img_size=args.img_size, num_classes=args.num_classes).cuda()
#
#     from thop import profile
#
#     flops, params = profile(model, (x,))
#
#     print('FLOPs = ' + str(flops / 1000 ** 3) + 'G')
#     print('Params = ' + str(params / 1000 ** 2) + 'M')
def val():
    logging.info("Validation ===>")
    dc_sum = 0
    model.eval()
    for i, val_sampled_batch in enumerate(valloader):
        val_image_batch, val_label_batch = val_sampled_batch["image"], val_sampled_batch["label"]
        val_image_batch, val_label_batch = val_image_batch.type(torch.FloatTensor), val_label_batch.type(
            torch.FloatTensor)
        val_image_batch, val_label_batch = val_image_batch.cuda().unsqueeze(1), val_label_batch.cuda().unsqueeze(1)

        val_outputs = model(val_image_batch)
        val_outputs = torch.argmax(torch.softmax(val_outputs[0], dim=1), dim=1).squeeze(0)
        dc_sum += dc(val_outputs.cpu().data.numpy(), val_label_batch[:].cpu().data.numpy())
    logging.info("avg_dsc: %f" % (dc_sum / len(valloader)))
    return dc_sum / len(valloader)


for epoch in iterator:
    model.train()
    train_loss = 0
    for i_batch, sampled_batch in enumerate(Train_loader):
        image_batch, label_batch = sampled_batch["image"], sampled_batch["label"]
        image_batch, label_batch = image_batch.type(torch.FloatTensor), label_batch.type(torch.FloatTensor)
        image_batch, label_batch = image_batch.cuda(), label_batch.cuda()

        outputs = model(image_batch)
        outputs2 = model2(label_batch)
        # Encoder
        se_encoder_feature1 = outputs[2][2]

        se_encoder_feature2 = outputs[2][1]

        se_encoder_feature3 = outputs[2][0]
        #
        re_encoder_feature1 = outputs2[2][2]

        re_encoder_feature2 = outputs2[2][1]

        re_encoder_feature3 = outputs2[2][0]

        # Decoder
        se_decoder_feature1 = outputs[3][0]

        se_decoder_feature2 = outputs[3][1]

        se_decoder_feature3 = outputs[3][2]

        re_decoder_feature1 = outputs2[3][0]
        #
        re_decoder_feature2 = outputs2[3][1]

        re_decoder_feature3 = outputs2[3][2]

        # 计算损失时确保两者维度一致
        loss_encoder1_1 = F.mse_loss(se_encoder_feature1, re_decoder_feature1)

        loss_encoder2_1 = F.mse_loss(se_encoder_feature2, re_decoder_feature2)

        loss_encoder3_1 = F.mse_loss(se_encoder_feature3, re_decoder_feature3)

        loss_decoder1_1 = F.mse_loss(se_decoder_feature1, re_encoder_feature1)

        loss_decoder2_1 = F.mse_loss(se_decoder_feature2, re_encoder_feature2)

        loss_decoder3_1 = F.mse_loss(se_decoder_feature3, re_encoder_feature3)

        # mid feature loss
        loss_midfeature = F.mse_loss(outputs[1], outputs2[1])

        # Loss
        loss_opt = (
                           loss_decoder1_1 + loss_decoder2_1 + loss_decoder3_1 + loss_encoder1_1 + loss_encoder2_1 + loss_encoder3_1 + loss_midfeature) / 3

        loss_ce = ce_loss(outputs[0], label_batch[:].long())  # [0]
        loss_dice = dice_loss(outputs[0], label_batch, softmax=True)  # [0]

        a = 0.035

        loss = 0.5 * loss_ce + 0.5 * loss_dice + a * loss_opt
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
        # lr_ = base_lr
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr_

        iter_num = iter_num + 1

        logging.info('iteration %d : loss : %f lr_: %f, loss_mid : %f, loss_opt : %f' % (iter_num, loss.item(), lr_, loss_midfeature.item(), loss_opt.item()))#
        train_loss += loss.item()
    Loss.append(train_loss / len(train_dataset))

    # loss visualization

    # fig1, ax1 = plt.subplots(figsize=(11, 8))
    # ax1.plot(range(epoch + 1), Loss)
    # ax1.set_title("Average trainset loss vs epochs")
    # ax1.set_xlabel("Epoch")
    # ax1.set_ylabel("Current loss")
    # plt.savefig('loss_vs_epochs_gauss.png')

    # plt.clf()
    # plt.close()

    if (epoch + 1) % save_interval == 0:
        avg_dcs = val()

        if avg_dcs > Best_dcs:
            avg_dcs, avg_hd = inference(args, model, testloader, args.test_save_dir)
            save_mode_path = os.path.join(args.save_path,
                                          'epoch={}_lr={}_avg_dcs={}_avg_hd={}.pth'.format(epoch, lr_, avg_dcs, avg_hd))
            torch.save(model.state_dict(), save_mode_path)
            logging.info("save model to {}".format(save_mode_path))
            # temp = 1
            # Best_dcs = avg_dcs

            Test_Accuracy.append(avg_dcs)

        # val visualization

        # fig2, ax2 = plt.subplots(figsize=(11, 8))
        # ax2.plot(range(int((epoch + 1) // save_interval)), Test_Accuracy)
        # ax2.set_title("Average val dataset dice score vs epochs")
        # ax2.set_xlabel("Epoch")
        # ax2.set_ylabel("Current dice score")
        # plt.savefig('val_dsc_vs_epochs_gauss.png')

        # plt.clf()
        # plt.close()

    if epoch >= args.max_epochs - 1:
        save_mode_path = os.path.join(args.save_path,
                                      'epoch={}_lr={}_avg_dcs={}_avg_hd={}.pth'.format(epoch, lr_, avg_dcs, avg_hd))
        torch.save(model.state_dict(), save_mode_path)
        logging.info("save model to {}".format(save_mode_path))
        iterator.close()
        break
