#!/usr/bin/env python
# -*- coding:utf-8 -*-

import argparse
import logging
import os

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from medpy.metric import dc
from torch.nn.modules.loss import CrossEntropyLoss
from torch.utils.data import DataLoader
from torchvision import transforms
from tqdm import tqdm
import torch.nn.functional as F

# import pytorch_ssim
#from Architecture.DATransUNet import CONFIGS as CONFIGS_ViT_seg
from Architecture.unet_model import UNet_hd as unet_re
from Architecture.unet_model import UNet_se as unet_se
from datasets.dataset_ACDC import ACDCdataset, RandomGenerator
# from model.MTUNet import MTUNet
# from Architecture.DATransUNet import DA_Transformer
#from utils.test_ACDC import inference
# import matplotlib.pyplot as plt
# from utils.utils import DiceLoss
class DiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(DiceLoss, self).__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor == i  # * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob.unsqueeze(1))
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _dice_loss(self, score, target):
        target = target.float()
        smooth = 1e-5
        intersect = torch.sum(score * target)
        y_sum = torch.sum(target * target)
        z_sum = torch.sum(score * score)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def forward(self, inputs, target, weight=None, softmax=False):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target)
        if weight is None:
            weight = [1] * self.n_classes

        assert inputs.size() == target.size(), 'predict {} & target {} shape do not match'.format(inputs.size(), target.size())
        class_wise_dice = []
        loss = 0.0
        for i in range(0, self.n_classes):
            dice = self._dice_loss(inputs[:, i], target[:, i])
            class_wise_dice.append(1.0 - dice.item())
            loss += dice * weight[i]
        return loss / self.n_classes

parser = argparse.ArgumentParser()
parser.add_argument("--batch_size", default=24, help="batch size")
parser.add_argument("--lr", default=0.01, help="learning rate")
parser.add_argument("--max_epochs", default=150)
parser.add_argument("--img_size", default=224)
parser.add_argument("--save_path", default="./checkpoint/ACDC/re/sgd3")
parser.add_argument("--n_gpu", default=1)
parser.add_argument("--checkpoint", default=None)
parser.add_argument("--list_dir", default="./datasets/ACDC/lists_ACDC")
parser.add_argument("--root_dir", default="./datasets/ACDC/")
parser.add_argument("--volume_path", default="./datasets/ACDC/test")
parser.add_argument("--z_spacing", default=1)
parser.add_argument("--num_classes", default=4)
parser.add_argument('--test_save_dir', default='./predictions/ACDC', help='saving prediction as nii!')
parser.add_argument("--patches_size", default=16)
# parser.add_argument("--n_skip", default=1)
parser.add_argument('--deterministic', type=int, default=1,
                    help='whether use deterministic training')
# parser.add_argument('--base_lr', type=float,  default=0.01,
#                     help='segmentation network learning rate')
# parser.add_argument('--img_size', type=int,
#                     default=224, help='input patch size of network input')
parser.add_argument('--seed', type=int,
                    default=1234, help='random seed')
parser.add_argument('--n_skip', type=int,
                    default=3, help='using number of skip-connect, default is num')
parser.add_argument('--vit_name', type=str,
                    default='R50-ViT-B_16', help='select one vit model')
parser.add_argument('--vit_patches_size', type=int,
                    default=16, help='vit_patches_size, default is 16')
args = parser.parse_args()

model = unet_re(n_channels=3, n_classes=4).cuda()#, num_classes=4
model.load_from(weights=np.load('./model/vit_checkpoint/imagenet21k/R50+ViT-B_16.npz'))
if args.checkpoint:
    model.load_state_dict(torch.load(args.checkpoint))

train_dataset = ACDCdataset(args.root_dir, args.list_dir, split="train", transform=
transforms.Compose(
    [RandomGenerator(output_size=[args.img_size, args.img_size])]))
Train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
db_val = ACDCdataset(base_dir=args.root_dir, list_dir=args.list_dir, split="valid")
valloader = DataLoader(db_val, batch_size=1, shuffle=False)
db_test = ACDCdataset(base_dir=args.volume_path, list_dir=args.list_dir, split="test")
testloader = DataLoader(db_test, batch_size=1, shuffle=False)

if args.n_gpu > 1:
    model = nn.DataParallel(model)

model = model.cuda()
model.train()
ce_loss = CrossEntropyLoss()
dice_loss = DiceLoss(args.num_classes)
save_interval = 3  # int(max_epoch/6)
# MSE = nn.MSELoss()
# L1loss = nn.L1Loss()
# yyloss = pytorch_ssim.SSIM(window_size=28, size_average=True)
iterator = tqdm(range(0, args.max_epochs), ncols=70)
iter_num = 0

Loss = []
Test_Accuracy = []

Best_dcs = 0.80
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s   %(levelname)s   %(message)s')

max_iterations = args.max_epochs * len(Train_loader)
base_lr = args.lr
#optimizer = optim.AdamW(model.parameters(), lr=base_lr, weight_decay=0.0001)


optimizer = optim.SGD(model.parameters(), lr=base_lr, momentum=0.9, weight_decay=0.0001)
# if __name__ == '__main__':
#     img_size = 224
#     x = torch.rand(1, 3, img_size, img_size).cuda()
#     model = DA_Transformer(config_vit, img_size=args.img_size, num_classes=args.num_classes).cuda()
#
#     from thop import profile
#
#     flops, params = profile(model, (x,))
#
#     print('FLOPs = ' + str(flops / 1000 ** 3) + 'G')
#     print('Params = ' + str(params / 1000 ** 2) + 'M')
def val():
    logging.info("Validation ===>")
    dc_sum = 0
    model.eval()
    for i, val_sampled_batch in enumerate(valloader):
        val_image_batch, val_label_batch = val_sampled_batch["image"], val_sampled_batch["label"]
        val_image_batch, val_label_batch = val_image_batch.type(torch.FloatTensor), val_label_batch.type(
            torch.FloatTensor)
        val_image_batch, val_label_batch = val_image_batch.cuda().unsqueeze(1), val_label_batch.cuda().unsqueeze(1)

        val_outputs = model(val_image_batch)
        val_outputs = torch.argmax(torch.softmax(val_outputs, dim=1), dim=1).squeeze(0)
        dc_sum += dc(val_outputs.cpu().data.numpy(), val_label_batch[:].cpu().data.numpy())
    logging.info("avg_dsc: %f" % (dc_sum / len(valloader)))
    return dc_sum / len(valloader)


for epoch in iterator:
    model.train()
    train_loss = 0
    for i_batch, sampled_batch in enumerate(Train_loader):
        image_batch, label_batch = sampled_batch["image"], sampled_batch["label"]
        image_batch, label_batch = image_batch.type(torch.FloatTensor), label_batch.type(torch.FloatTensor)
        image_batch, label_batch = image_batch.cuda(), label_batch.cuda()

        outputs = model(label_batch)  # , label_batch
        loss_ssim = F.l1_loss(outputs[0], image_batch)
        loss_mse = F.mse_loss(outputs[0], image_batch)
        # loss_ssim = ssim(outputs[0], image_batch, data_range=1.0, win_size=11, size_average=True)#
        # loss_ssim1 = 0.2 * loss_ssim
        loss = 0.6 * loss_mse + 0.4 * loss_ssim

        # loss_ce = ce_loss(outputs, label_batch[:].long())
        # loss_dice = dice_loss(outputs, label_batch[:], softmax=True)
        # loss = loss_dice * 0.5 + loss_ce * 0.5

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
        # lr_ = base_lr
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr_

        iter_num = iter_num + 1

        logging.info('iteration %d : loss : %f lr_: %f, loss_mse: %f, loss_ssim: %f' % (iter_num, loss.item(), lr_, loss_mse.item(), loss_ssim.item()))
        train_loss += loss.item()
    Loss.append(train_loss / len(train_dataset))


    if epoch >= args.max_epochs - 1:
        save_mode_path = os.path.join(args.save_path,
                                      'epoch={}_lr={}'.format(epoch, lr_))
        # save_mode_path = os.path.join(args.save_path,
        #                               'epoch={}_lr={}_avg_dcs={}_avg_hd={}.pth'.format(epoch, lr_, avg_dcs, avg_hd))
        torch.save(model.state_dict(), save_mode_path)
        logging.info("save model to {}".format(save_mode_path))
        iterator.close()
        break
